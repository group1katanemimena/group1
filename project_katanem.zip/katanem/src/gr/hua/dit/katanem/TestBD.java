package gr.hua.dit.katanem;

import java.sql.Connection;
import java.sql.DriverManager;

public class TestBD {

	public static void main(String[] args) {
		String jdbcUrl = "jdbc:mysql://XXXXXXXXXXX/hbstudent?useSSL=false";
        String user = "hbstudent";
        String pass = "changeit";

        try {
                System.out.println("Connecting to database: " + jdbcUrl);
                Connection con = DriverManager.getConnection(jdbcUrl, user, pass);
                System.out.println("Connection success");

        } catch (Exception e) {
                e.printStackTrace();
        }

	}

}
