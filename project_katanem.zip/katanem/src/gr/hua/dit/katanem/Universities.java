package gr.hua.dit.katanem;


import java.io.Serializable;
import java.util.HashMap;



public class Universities implements Serializable {

	 public String name;
	 public int seats;
	 
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getSeats() {
		return seats;
	}
	public void setSeats(int seats) {
		this.seats = seats;
	}
	public Universities() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Universities(String name, int seats) {
		super();
		this.name = name;
		this.seats = seats;
		
	}
	@Override
	public String toString() {
		return "Universities [name=" + name + ", seats=" + seats + "]";
	}
	
	
	
	public static void main ( String[] args) {
	
	       HashMap<String,Integer> UniversitiesList = new HashMap<String,Integer>();
	       

	       UniversitiesList.put("M.I.T", 0);
	       UniversitiesList.put("Harvard", 0);
	       UniversitiesList.put("University_of_Sydney", 0);
	       UniversitiesList.put("Washington_University", 0);
	       UniversitiesList.put("LSE", 0);
	       UniversitiesList.put("Standford_University", 0);
	       UniversitiesList.put("UCLA", 0);
	       
	       for(String item: UniversitiesList.keySet() ) {
	    	   
	    	   System.out.println(item+ "=" +UniversitiesList.get(item));
	    	  
	       }
	       

	
	}
	
	
	
}	

