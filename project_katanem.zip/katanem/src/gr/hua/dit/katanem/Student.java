package gr.hua.dit.katanem;

import java.io.Serializable;

public class Student implements Serializable {
	
	private String email;
	private int password;
	public String getId() {
		return email;
	}
	
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	@Override
	public String toString() {
		return "Student [Id=" + email + ", password=" + password + "]";
	}

	public Student(String id, int password) {
		super();
		email = id;
		this.password = password;
	}
	
	public String getID() {
		return email;
	}

	public void setID(String id) {
		email = id;
	}
	public int getPassword() {
		return password;
	}
	
	public void setPassword(int password) {
		this.password = password;
	}

	

	

}
