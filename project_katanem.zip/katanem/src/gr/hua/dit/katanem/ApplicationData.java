package gr.hua.dit.katanem;


import java.awt.List;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

public class ApplicationData implements Serializable  {
	private String email;
	private String Uni1;
	private String Uni2;
	private String Uni3;
	private String certificate;
	
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getUni1() {
		return Uni1;
	}
	public void setUni1(String uni1) {
		Uni1 = uni1;
	}
	public String getUni2() {
		return Uni2;
	}
	public void setUni2(String uni2) {
		Uni2 = uni2;
	}
	public String getUni3() {
		return Uni3;
	}
	public void setUni3(String uni3) {
		Uni3 = uni3;
	}
	public String getCertificate() {
		return certificate;
	}
	public void setCertificate(String certificate) {
		this.certificate = certificate;
	}
	public ApplicationData() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ApplicationData(String email, String uni1, String uni2, String uni3, String certificate) {
		super();
		this.email = email;
		Uni1 = uni1;
		Uni2 = uni2;
		Uni3 = uni3;
		this.certificate = certificate;
	}
	@Override
	public String toString() {
		return "ApplicationData [email=" + email + ", Uni1=" + Uni1 + ", Uni2=" + Uni2 + ", Uni3=" + Uni3
				+ ", certificate=" + certificate + "]";
	}
	
	public static void main ( String[] args) {
		
	      // HashMap<Integer,ApplicationData > ApplicationList = new HashMap<Integer,ApplicationData>();
	       
	       ArrayList<String> EmailList = new ArrayList<String>();
	       ArrayList<String> Uni1List = new ArrayList<String>();
	       ArrayList<String> Uni2List = new ArrayList<String>();
	       ArrayList<String> Uni3List = new ArrayList<String>();
	       ArrayList<String> CertificateList = new ArrayList<String>();
	       
	       EmailList.add("it21661@hua.gr");
	       Uni1List.add("M.I.T");
	       Uni2List.add("Harvard");
	       Uni3List.add("LSE");
	       CertificateList.add("/path");
	       
	       int i;
	       for (i=0; i<= 100; i++) {
	    	   System.out.println(EmailList.get(i)+ " , "+ Uni1List.get(i)+ " , "+ Uni2List.get(i)+ " , "+ Uni3List.get(i)+ " , "+ CertificateList.get(i));
	    	   
	       }


	
	}
	
	
	
	
	
	
}
