//den xriazete ta pernoyme apo vasi (1:07:00)
//tha exoume data access adikimeno to opio kalei mia methodo get student kai epistrefei student
//epistrefou adikimena kai ta metasximatizoume se json
package gr.hua.dit.ds.demorest11.controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import gr.hua.dit.ds.demorest11.entity.Student;

@RestController
@RequestMapping("/api")

public class StudentRestController {

	 @GetMapping("/hello")
     public String sayHello() {
             return "Hello World!";
     }
	 
	 
	 private List<Student> theStudents;
     
     @PostConstruct
     public void loadData() {
             theStudents = new ArrayList<>();
             theStudents.add(new Student("Nick","Cave"));
             theStudents.add(new Student("John","Travolta"));
             theStudents.add(new Student("Jason","Cannon"));
     }

     @GetMapping("/students")
     public List<Student>  getStudnets() {
             return theStudents;
             
     }
     
     @GetMapping("/students/{studentId}")
     public Student getStudent(@PathVariable int studentId) {
             
             return theStudents.get(studentId);        
     }
	 
     
     
     
     
     
     
     
	 
	 
}
